#!/bin/bash

a=$(wc -c < quotes.txt)
b=$(wc -l < quotes.txt)
c=$(wc -w < quotes.txt)

echo "Size of the file: $a bytes"
echo "Total number of lines in the file: $b"
echo "Total number of words in the file: $c"

i=1

while read -r line
do
    d=$(wc -w <<< $line)
    echo "Line No: $i - $d"
    ((i++))
done < quotes.txt



cat quotes.txt | tr " " "\n" | tr -d ",.~?:;" | sort | uniq -c | while read count name
do
        if [ ${count} -gt 1 ]
        then
                echo "${name} ${count}"
        fi
done