awk '!/^[[:blank:]]*$/' quotes.txt > temp.txt

while read -r line
do
    quote=$(cut -d "~" -f1 <<< $line)
    author=$(cut -d "~" -f2 <<< $line)
    echo "$author once said, "$quote"" >> speech.txt
done < temp.txt