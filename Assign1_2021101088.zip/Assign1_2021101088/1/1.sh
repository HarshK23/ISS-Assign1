#!/bin/bash

awk '!/^[[:blank:]]*$/' quotes.txt > temp.txt

awk '!seen[$0]++' temp.txt > answer.txt

