GitHub Repository link: https://github.com/HarshK23/ISS-Assign1

Q1: Execute using ./1.sh. The script works by first removing the empty lines from quotes.txt and storing the output in temp.txt, then reading the contents of temp.txt to remove duplicates and storing the final output in answer.txt

Q2: Execute using ./2.sh. The script works by first removing the empty lines from quotes.txt and storing the output in temp.txt, then giving the final output in speech.txt

Q3: Execute using ./3.sh.

Q4: Execute using ./4.sh. The input format is assumed to be the same as the one given in the Assignment PDF. 

Q5: Execute using ./5.sh. One input string for all three parts is assumed. 