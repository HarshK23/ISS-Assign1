#!/bin/bash

read -p "Enter a string: " str

len=${#str}

for ((i=$len-1; i >= 0; i--))
do
    rev="$rev${str:$i:1}"
done

echo "Reversed string: $rev"

echo $rev | tr "[a-y], z" "[b-z], a" | tr "[A-Y], Z" "[B-Z], A" 

for ((i=$len /2 -1; i >=0 ; i--))
do
    rev2="$rev2${str:$i:1}"
done

for ((i=$len /2; i < $len ; i++))
do
    rev3="$rev3${str:$i:1}"
done

echo $rev2$rev3